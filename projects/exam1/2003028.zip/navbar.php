<?php
include("session_checking.php");
?>

<nav class="navbar navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="Dashboard.php">Employee Admin Panel</a>
        <a class="navbar-brand" href="AddEmployee.php">Add Employee</a>
        <a class="navbar-brand" href="DeleteEmployee.php">Delete Employee</a>
        <a class="navbar-brand" href="Logout.php">Logout</a>
    </div>
</nav>
<p class="container mt-5">
    Welcome to admin panel. You can add or delete employees from here.
</p>